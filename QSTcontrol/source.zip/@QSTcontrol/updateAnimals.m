function updateAnimals(obj)

% get subdirectories
subDirs = dir(obj.dirData);
subDirs = {subDirs([subDirs.isdir]).name};
subDirs = subDirs(cellfun(@isempty,regexp(subDirs,'^\.')));
if isempty(subDirs)
    subDirs = {''};
end

% set string
obj.h.animal.listbox.id.String = subDirs;

% select most recent
subDate = nan(size(subDirs));
for idxSub = 1:length(subDirs)
    tmp = rfind(fullfile(obj.dirData,subDirs{idxSub}),'.','rmax',1);
    tmp = tmp(cellfun(@isempty,regexp({tmp.name},'^\.')));
    subDate(idxSub) = max(datenum({tmp.date}));
end
[~,obj.h.animal.listbox.id.Value] = max(subDate);