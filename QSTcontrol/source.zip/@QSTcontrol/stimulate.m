function stimulate(obj,fnOut)

% release session (in case the previous run was incomplete)
if obj.DAQ.IsRunning
    obj.DAQ.stop
end
release(obj.DAQ);

% add listener for plotting/saving -- see function plotData() below
lh = addlistener(obj.DAQ,'DataAvailable',@plotData);

if isempty(obj.p)
    % single stimulation: use default values for tPre (time before onset of
    % stimulus) and tPost (time after onset of stimulus). Obtain duration
    % of vibration from respective GUI fields.
    tPre	= 1;
    tPost 	= 2;
    vibDur  = [obj.h.ThermodeA.edit.vibDur.Value ...
        obj.h.ThermodeB.edit.vibDur.Value] / 1000;
else
    % protocol run: use values from protocol structure
    tPre    = obj.p(obj.idxStim).tPre  / 1000;
    tPost   = obj.p(obj.idxStim).tPost / 1000;
    vibDur  = [obj.p(obj.idxStim).ThermodeA.VibrationDuration ...
        obj.p(obj.idxStim).ThermodeB.VibrationDuration] / 1000;
end
tTotal  = tPre + tPost;
    
% prepare DAQ output
out = zeros(tTotal*obj.DAQ.Rate,5);     % preallocate with zeros
out(1,1)    = 1;                        % TTL ScanImage: Start
out(end,2)  = 1;                        % TTL ScanImage: Stop
out(1,3)    = 1;                        % TTL ScanImage: Next File
if vibDur(1)>0
    tmp         = (tPre*obj.DAQ.Rate) + (1:vibDur(1)*obj.DAQ.Rate);
    out(tmp,4)  = 1;
end
if vibDur(2)>0
    tmp         = (tPre*obj.DAQ.Rate) + (1:vibDur(2)*obj.DAQ.Rate);
    out(tmp,5)  = 1;
end
obj.DAQ.queueOutputData(out)            % queue data
prepare(obj.DAQ)                        % prepare data acquisition

% wait for thermodes to reach neutral temperature
obj.waitForNeutral

% open output file (if filename provided)
if nargin > 1
    output  = true;
    fid1    = fopen(fnOut,'w');
else
    output  = false;
end

% run stimulation
startBackground(obj.DAQ);               % start data acquisition
pause(tPre-0.015)                       % wait for t=0s
fprintf(obj.s(1).s,'L');                % start stimulus on thermode A
fprintf(obj.s(2).s,'L');                % start stimulus on thermode B
try
    wait(obj.DAQ,tTotal+1)          	% wait for data acquisition
catch me
    warning(me.identifier,'%s',...      % rethrow timeout error as warning
        me.message); 
end

% close output file
if output
    fclose(fid1);
end

% delete listener
delete(lh);


function plotData(~,event)
    
    % build indices for plotting
    a   = event.Source.NotifyWhenDataAvailableExceeds;
    b   = event.Source.ScansAcquired;
    idx = (1:a)+(b-a);
    
    % scale data from thermodes
    dat = event.Data;
    dat(:,1:10) = dat(:,1:10) * 17.0898 - 5.0176;
    
    % plot data
    for ii = 1:5
        obj.h.ThermodeA.plot(ii).YData(idx) = dat(:,ii);
        obj.h.ThermodeB.plot(ii).YData(idx) = dat(:,ii+5);
    end
    
    % save to disk (optional)
    if output
        fwrite(fid1,[event.TimeStamps-tPre,dat,out(idx,:)]','double');
    end
end
end