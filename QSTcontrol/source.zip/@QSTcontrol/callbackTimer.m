function callbackTimer(obj,~,~)

if ~obj.DAQ.IsRunning && ~obj.isRunning
    if obj.s(1).existPort
        obj.h.ThermodeA.battery.Value = obj.s(1).battery;
    end
    if obj.s(2).existPort
        obj.h.ThermodeB.battery.Value = obj.s(2).battery;
    end
end