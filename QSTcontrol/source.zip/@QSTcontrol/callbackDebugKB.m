function callbackDebugKB(obj,~,~)

keyboard