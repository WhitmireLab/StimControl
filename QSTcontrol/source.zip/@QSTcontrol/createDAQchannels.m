function createDAQchannels(obj)

% Analog Input: Thermode Surfaces
ch  = obj.DAQ.addAnalogInputChannel('Dev1',[1:5 9:13],'Voltage');
tmp = [arrayfun(@(x) {['Surface A' num2str(x)]},1:5) ...
    arrayfun(@(x) {['Surface B' num2str(x)]},1:5)];
[ch.Name] = tmp{:};
set(ch,...
    'TerminalConfig',   'SingleEnded', ...
    'Range',            [-5 5]);

% Analog Input: DC Temperature Controller
ch = obj.DAQ.addAnalogInputChannel('Dev1',7,'Voltage');
set(ch,...
    'Name',             'DC Temperature Controller', ...
    'TerminalConfig',   'SingleEnded')

% TTL Input: Stimulus Onset
ch = obj.DAQ.addDigitalChannel('Dev1','port0/line1:2','InputOnly');
ch(1).Name = 'TTL Thermode A: Onset';
ch(2).Name = 'TTL Thermode B: Onset';

% TTL Input: Galvo
ch = obj.DAQ.addDigitalChannel('Dev1','port0/line20:21','InputOnly');
ch(1).Name = 'TTL ScanImage: Res Galvo';
ch(2).Name = 'TTL ScanImage: Y Galvo';

% TTL Output: ScanImage
ch = obj.DAQ.addDigitalChannel('Dev1','port0/line17:19','OutputOnly');
ch(1).Name = 'TTL ScanImage: Start';
ch(2).Name = 'TTL ScanImage: Stop';
ch(3).Name = 'TTL ScanImage: Next File';

% Analog Output: Vibration Motors
ch = obj.DAQ.addDigitalChannel('Dev1','port0/line22:23','OutputOnly');
ch(1).Name = 'Vibration A';
ch(2).Name = 'Vibration B';