function enableThermodeEdit(obj,bool)

enable = {'off','on'};
enable = enable{bool+1};
for thermode = {'ThermodeA','ThermodeB'}
    set(struct2array(obj.h.(thermode{:}).edit),'Enable',enable);
    set(struct2array(obj.h.(thermode{:}).check),'Enable',enable);
    set(struct2array(obj.h.(thermode{:}).toggle),'Enable',enable);
    if bool
        for tmp = 'CVRD'
            callbackThermodeSync(obj,obj.h.(thermode{:}).check.(tmp))
        end
    end
end