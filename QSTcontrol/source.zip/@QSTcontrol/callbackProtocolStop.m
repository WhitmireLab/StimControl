function callbackProtocolStop(obj,hButton,~)

obj.isRunning = false;
obj.s(1).query('A');
obj.s(2).query('A');
obj.DAQ.stop